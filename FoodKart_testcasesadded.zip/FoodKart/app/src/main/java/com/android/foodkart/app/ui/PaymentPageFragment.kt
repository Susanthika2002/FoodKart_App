package com.android.foodkart.app.ui

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.android.foodkart.app.R
import com.android.foodkart.app.data.UserData
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentPaymentpageBinding
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref
import kotlin.random.Random


private const val CHANNEL_ID = "foodkart_channel"

class PaymentPageFragment : Fragment(R.layout.fragment_paymentpage) {

    lateinit var binding: FragmentPaymentpageBinding
    lateinit var myDialog: MyDialog
    lateinit var viewmodel : MainViewmodel
    lateinit var sharedPref : SharedPref
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentPaymentpageBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        myDialog = MyDialog(requireContext())
        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        sharedPref = SharedPref(requireContext())

        binding.cdPlaceorder.setOnClickListener {
            val cardholderName = binding.edCardholdername.text.toString()
            val cardNumber = binding.edCardnumber.text.toString()
            val expiryDate = binding.edExpirydate.text.toString()
            val cvv = binding.edCvv.text.toString()
            if (cardholderName.isEmpty() || cardNumber.isEmpty() || expiryDate.isEmpty() || cvv.isEmpty()){
                Toast.makeText(requireContext(),"Please enter card details",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val userData = sharedPref.getUserData()
            viewmodel.updateUser(
                userData.apply {
                    this.yourCart = listOf()
                }
            )
            myDialog.showProgressDialog("Placing order",this)
        }

        viewmodel.userUpdatedLive.observe(viewLifecycleOwner, Observer {
            myDialog.dismissProgressDialog()
            sharedPref.setUserData(it)
            sendNotification()
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.cartFragment)
        })

        viewmodel.errorUserUpdatedLive.observe(viewLifecycleOwner, Observer {
            myDialog.dismissProgressDialog()
            Toast.makeText(requireContext(),it,Toast.LENGTH_SHORT).show()
        })



    }

    private fun sendNotification(){

        val notificationManager = requireActivity().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationID = Random.nextInt()

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel(notificationManager)
        }

        val notification = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setContentTitle("Order Placed")
            .setContentText("Just now")
            .setSmallIcon(R.drawable.ic_stat_notification)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_SOUND)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        notificationManager.notify(notificationID, notification)

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel(notificationManager: NotificationManager) {
        val channelName = "Foodkart"
        val channel = NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Foodkart channel description"
            enableLights(true)
            lightColor = Color.GREEN
        }
        notificationManager.createNotificationChannel(channel)
    }

}