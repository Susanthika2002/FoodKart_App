package com.android.foodkart.app.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.foodkart.app.data.CartData
import com.android.foodkart.app.databinding.RvCartBinding
import com.android.foodkart.app.databinding.RvCartpriceBinding
import com.android.foodkart.app.databinding.RvFooditemBinding
import com.bumptech.glide.RequestManager

class Cart2Adapter(val glide: RequestManager)  : RecyclerView.Adapter<Cart2Adapter.LevelViewHolder>()  {

    class LevelViewHolder(val binding : RvCartpriceBinding) : RecyclerView.ViewHolder(binding.root)

    private var onItemClickListenerForMinus: ((CartData) -> Unit)? = null

    fun setOnItemClickListenerForMinus(position: (CartData) -> Unit) {
        onItemClickListenerForMinus = position
    }

    private var onItemClickListenerForAdd: ((CartData) -> Unit)? = null

    fun setOnItemClickListenerForAdd(position: (CartData) -> Unit) {
        onItemClickListenerForAdd = position
    }


    private var onItemClickListenerDelete: ((CartData) -> Unit)? = null

    fun setOnItemClickListenerDelete(position: (CartData) -> Unit) {
        onItemClickListenerDelete = position
    }


    private var onItemLongClickListener: ((CartData) -> Unit)? = null

    fun setOnItemLongClickListener(position: (CartData) -> Unit) {
        onItemLongClickListener = position
    }


    private val diffCallback = object : DiffUtil.ItemCallback<CartData>() {

        override fun areContentsTheSame(oldItem: CartData, newItem: CartData): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: CartData, newItem: CartData): Boolean {
            return false
        }

    }


    private val differ = AsyncListDiffer(this, diffCallback)

    var levelList : List<CartData>
        get() = differ.currentList
        set(value) = differ.submitList(value)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = RvCartpriceBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return  LevelViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return levelList.size
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {

        val data = levelList[position]
        holder.itemView.apply {

            with(holder) {

                binding.tvFoodname.text = data.foodData.name
                binding.tvPrice.text = "$" + data.foodData.price + " * ${data.count}"

            }


    }

    }

}