package com.android.foodkart.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.app.ActivityCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.android.foodkart.app.databinding.ActivityMainBinding
import com.android.foodkart.app.others.SharedPref
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var currentLocation: Location? = null
    lateinit var locationManager: LocationManager
    lateinit var locationByGps : Location
    lateinit var locationByNetwork : Location
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        binding.bottomView.setupWithNavController(navController)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.homeFragment2,R.id.nearByFragment,R.id.cartFragment,R.id.supportFragment -> binding.bottomView.visibility = View.VISIBLE
                else -> binding.bottomView.visibility = View.GONE
            }
        }

     isLocationPermissionGranted()

    }

    private fun getLocationForAddress() {


        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val hasGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

        val hasNetwork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)


        val gpsLocationListener: LocationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                locationByGps= location
            }

            override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }

        val networkLocationListener: LocationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                locationByNetwork= location
            }

            override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }


        if (hasGps) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                5000,
                0F,
                gpsLocationListener
            )
        }
//------------------------------------------------------//
        if (hasNetwork) {
            locationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER,
                5000,
                0F,
                networkLocationListener
            )
        }


        val lastKnownLocationByGps =
            locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        lastKnownLocationByGps?.let {
            locationByGps = lastKnownLocationByGps
        }

        val lastKnownLocationByNetwork =
            locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        lastKnownLocationByNetwork?.let {
            locationByNetwork = lastKnownLocationByNetwork
        }

        if (locationByGps.accuracy > locationByNetwork!!.accuracy) {
            currentLocation = locationByGps
            getAddressInfo(currentLocation!!.latitude, currentLocation!!.longitude)
            // use latitude and longitude as per your need
        } else {
            currentLocation = locationByNetwork
            getAddressInfo(currentLocation!!.latitude, currentLocation!!.longitude)
            // use latitude and longitude as per your need
        }

    }


     fun isLocationPermissionGranted(): Boolean {
        return if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                100
            )
            false
        } else {
            getLocationForAddress()
            true
        }
    }

    private fun getAddressInfo(latitude:Double, longitude:Double){
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses= geocoder.getFromLocation(latitude, longitude, 1)

        val address = addresses?.get(0)?.getAddressLine(0)
        val city = addresses?.get(0)?.locality
        val state= addresses?.get(0)?.adminArea
        val country = addresses?.get(0)?.countryName
        val postalCode = addresses?.get(0)?.postalCode
        val knownName = addresses?.get(0)?.featureName

        Log.d("MainActivity","Address $address city $city state $state country $country $postalCode $postalCode")

        val sharedPref = SharedPref(this)
        sharedPref.setAddress("$address, $city, $state, $country")
        sharedPref.setAddress(" $city, $country")

    }

}