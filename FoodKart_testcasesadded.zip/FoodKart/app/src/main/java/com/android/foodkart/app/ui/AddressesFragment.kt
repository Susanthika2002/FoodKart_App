package com.android.foodkart.app.ui

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.foodkart.app.R
import com.android.foodkart.app.adapter.AddressAdapter
import com.android.foodkart.app.adapter.FoodItemAdapter
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentAddressesBinding
import com.android.foodkart.app.databinding.FragmentHomeBinding
import com.android.foodkart.app.others.Constants
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref
import kotlin.random.Random

class AddressesFragment : Fragment(R.layout.fragment_addresses) {


    lateinit var binding: FragmentAddressesBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    lateinit var addressAdapter: AddressAdapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentAddressesBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())

        val userData = sharedPref.getUserData()

        addressAdapter = AddressAdapter()

        binding.rvAddress.adapter = addressAdapter
        binding.rvAddress.layoutManager = LinearLayoutManager(requireContext())

        addressAdapter.levelList = userData.address


        binding.btAddaddress.setOnClickListener {
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_addressesFragment_to_addAddressFragment)
        }


        binding.ivAdd.setOnClickListener {
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_addressesFragment_to_addAddressFragment)
        }

        addressAdapter.setOnItemClickListener {
            Constants.curAddressData = it
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_addAddressFragment_to_updateAddressFragment)
        }

        if (userData.address.isNotEmpty()){
            binding.cdPlaceorder.visibility = View.VISIBLE
        }

        binding.ivBack.setOnClickListener {
            requireActivity().onBackPressed()
        }


        binding.cdPlaceorder.setOnClickListener {
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_addressesFragment_to_paymentPageFragment)
        }

    }


}