package com.android.foodkart.app.ui.login

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.android.foodkart.app.R
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentLoginBinding
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref

class LoginFragment : Fragment(R.layout.fragment_login) {

    lateinit var binding: FragmentLoginBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentLoginBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())

        binding.tvRegister.setOnClickListener {
            Navigation.findNavController(requireActivity(),R.id.nav_host_fragment_content_main).navigate(R.id.action_loginFragment_to_registerFragment)
        }

        binding.cdLogin.setOnClickListener {
            login()
        }


        setCallbacks()



    }

    private fun login() {

        val phone = binding.edPhonenumber.text.toString()
        val password = binding.edPassword.text.toString()

        if (phone.isEmpty() || password.isEmpty()){
            Toast.makeText(requireContext(), "Please enter credentials", Toast.LENGTH_SHORT).show()
            return
        }

        viewmodel.signInUser(phone, password)

        myDialog.showProgressDialog("Please wait",this)


    }

    private fun setCallbacks() {


        viewmodel.userCreatedLive.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            myDialog.dismissProgressDialog()
            sharedPref.setUserData(it)
            Navigation.findNavController(requireActivity(),R.id.nav_host_fragment_content_main).navigate(R.id.action_loginFragment_to_homeFragment2)

        })

        viewmodel.errorUserCreatedLive.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            myDialog.dismissProgressDialog()
            myDialog.showErrorAlertDialog(it)
        })

    }

}