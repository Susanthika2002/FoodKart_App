package com.android.foodkart.app.others

import com.android.foodkart.app.data.AddressData
import com.android.foodkart.app.data.RestaurantData

object Constants {

    var restaurantData = RestaurantData()

    var curAddressData = AddressData()

}