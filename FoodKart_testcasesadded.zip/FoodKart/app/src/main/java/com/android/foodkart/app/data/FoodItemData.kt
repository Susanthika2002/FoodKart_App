package com.android.foodkart.app.data

data class FoodItemData(
    val foodItem : Int = 0
)