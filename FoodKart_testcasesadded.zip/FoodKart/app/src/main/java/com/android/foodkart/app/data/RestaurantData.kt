package com.android.foodkart.app.data

data class RestaurantData(
    val id: String = "",
    val image: String = "",
    val name: String = "",
    val text: String = "",
    val rating: Int = 0,
    val km: String = ""
)
