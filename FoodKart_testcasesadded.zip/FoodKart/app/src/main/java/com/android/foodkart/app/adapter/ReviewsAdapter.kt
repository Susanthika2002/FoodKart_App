package com.android.foodkart.app.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.foodkart.app.data.ReviewData
import com.android.foodkart.app.databinding.RvAddressBinding
import com.android.foodkart.app.databinding.RvFoodBinding
import com.android.foodkart.app.databinding.RvFooditemBinding
import com.android.foodkart.app.databinding.RvReviewBinding
import com.bumptech.glide.RequestManager

class ReviewsAdapter()  : RecyclerView.Adapter<ReviewsAdapter.LevelViewHolder>()  {

    class LevelViewHolder(val binding : RvReviewBinding) : RecyclerView.ViewHolder(binding.root)

    private var onItemClickListener: ((ReviewData) -> Unit)? = null

    fun setOnItemClickListener(position: (ReviewData) -> Unit) {
        onItemClickListener = position
    }

    private var onItemLongClickListener: ((ReviewData) -> Unit)? = null

    fun setOnItemLongClickListener(position: (ReviewData) -> Unit) {
        onItemLongClickListener = position
    }


    private val diffCallback = object : DiffUtil.ItemCallback<ReviewData>() {

        override fun areContentsTheSame(oldItem: ReviewData, newItem: ReviewData): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: ReviewData, newItem: ReviewData): Boolean {
            return false
        }

    }


    private val differ = AsyncListDiffer(this, diffCallback)

    var levelList : List<ReviewData>
        get() = differ.currentList
        set(value) = differ.submitList(value)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = RvReviewBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return  LevelViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return levelList.size
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {

        val data = levelList[position]
        holder.itemView.apply {

            with(holder) {

                binding.tvPersonname.text = data.name
                binding.tvPersonnameValue.text = data.review

            }


            setOnClickListener {

            }

        }
    }



}