package com.android.foodkart.app.data

data class FoodData(
    val id: String = "",
    val name: String = "",
    val image: String = "",
    val text: String = "",
    val rating: Int = 0,
    val price: Int = 0,
    val restaurants : List<String>  = listOf(),
    val foodDetails: String = "",
    val reviews: List<ReviewData> = listOf()
)
data class ReviewData(
    val name: String = "",
    val review : String = ""
)
