package com.android.foodkart.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate


class FoodKartApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        setTheme(R.style.Theme_FoodKart)


    }

}