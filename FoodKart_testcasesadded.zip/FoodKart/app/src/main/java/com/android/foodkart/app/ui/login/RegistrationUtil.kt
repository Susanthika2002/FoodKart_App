package com.android.foodkart.app.ui.login

import android.content.Context
import android.widget.Toast


object RegistrationUtil {

    fun validRegistrationInputs(phone: String, password: String, confirmPassword: String, firstName: String, lastName: String): Boolean {

        if (phone.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || firstName.isEmpty() || lastName.isEmpty()){
            return false
        }

        return true

    }

    fun validConfirmPassword(password: String, confirmPassword: String): Boolean {

        if (password != confirmPassword){
            return false
        }

        return true

    }

    fun validPasswordDigits(password: String): Boolean {

        if (password.length < 4){
            return false
        }

        return true

    }

    fun validPhoneNumber(phonenumber : String): Boolean {

        if (phonenumber.length != 10){
            return false
        }

        return true

    }




}