package com.android.foodkart.app.ui

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.foodkart.app.R
import com.android.foodkart.app.adapter.Cart2Adapter
import com.android.foodkart.app.adapter.CartAdapter
import com.android.foodkart.app.data.UserData
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentCartBinding
import com.android.foodkart.app.databinding.FragmentHomeBinding
import com.android.foodkart.app.databinding.FragmentLoginBinding
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref
import com.bumptech.glide.Glide

class CartFragment : Fragment(R.layout.fragment_cart) {

    lateinit var binding: FragmentCartBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    lateinit var  userData: UserData
    lateinit var cartAdapter: CartAdapter
    lateinit var cartAdapter2: Cart2Adapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentCartBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())
        userData = sharedPref.getUserData()

        val glide = Glide.with(requireActivity())
        cartAdapter = CartAdapter(glide)
        cartAdapter2 = Cart2Adapter(glide)

        binding.rvOrders.adapter = cartAdapter
        binding.rvOrders.layoutManager = LinearLayoutManager(requireContext())

        binding.rvAmount.adapter = cartAdapter2
        binding.rvAmount.layoutManager = LinearLayoutManager(requireContext())

        if (userData.yourCart.isEmpty()){
            binding.ctView.visibility = View.GONE
            binding.tvNoordersound.visibility = View.VISIBLE
        }else{
            binding.ctView.visibility = View.VISIBLE
            binding.tvNoordersound.visibility = View.GONE
        }


        cartAdapter.levelList = userData.yourCart
        cartAdapter2.levelList = userData.yourCart

        cartAdapter.setOnItemClickListenerForAdd {  cartData ->
            val oldCartItems = userData.yourCart.toMutableList()
            val removeItem = oldCartItems.filter { it.id == cartData.id }
            oldCartItems.removeAll(removeItem)
            oldCartItems.add(cartData)
            sharedPref.setUserData(userData.apply {
                this.yourCart = oldCartItems
            })
            val total  : Int = getTotalAmount()

            binding.tvPrice.text = "$total"

        }

        cartAdapter.setOnItemClickListenerForMinus {  cartData ->
            val oldCartItems = userData.yourCart.toMutableList()
            val removeItem = oldCartItems.filter { it.id == cartData.id }
            oldCartItems.removeAll(removeItem)
            oldCartItems.add(cartData)
            sharedPref.setUserData(userData.apply {
                this.yourCart = oldCartItems
            })
            val total  : Int = getTotalAmount()

            binding.tvPrice.text = "$total"

        }



        activity?.onBackPressedDispatcher?.addCallback(viewLifecycleOwner,object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                    .navigate(R.id.homeFragment2)
            }
        })



        cartAdapter.setOnItemClickListenerDelete {  cartData ->
            val oldCartItems = userData.yourCart.toMutableList()
            val removeItem = oldCartItems.filter { it.id == cartData.id }
            oldCartItems.removeAll(removeItem)
            sharedPref.setUserData(userData.apply {
                this.yourCart = oldCartItems
            })

            val total  : Int = getTotalAmount()

            binding.tvPrice.text = "$total"

            val carts = sharedPref.getUserData().yourCart

            cartAdapter.levelList = carts
            cartAdapter2.levelList = carts

            cartAdapter.notifyDataSetChanged()
            cartAdapter2.notifyDataSetChanged()

        }

        val total  : Int = getTotalAmount()

        binding.tvPrice.text = "$total"

        binding.cdPlaceorder.setOnClickListener {
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_cartFragment_to_addressesFragment)
        }

    }

    private fun getTotalAmount(): Int {

        var amount = 0

        val carts = sharedPref.getUserData().yourCart

        for (cartItem in carts){
            amount += (cartItem.foodData.price * cartItem.count)
        }

        return  amount

    }

}