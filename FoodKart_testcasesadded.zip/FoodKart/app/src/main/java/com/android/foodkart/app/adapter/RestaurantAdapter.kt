package com.android.foodkart.app.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.foodkart.app.data.RestaurantData
import com.android.foodkart.app.databinding.RvFooditemBinding
import com.android.foodkart.app.databinding.RvRestaurantBinding
import com.bumptech.glide.RequestManager

class RestaurantAdapter(val glide: RequestManager)  : RecyclerView.Adapter<RestaurantAdapter.LevelViewHolder>()  {

    class LevelViewHolder(val binding : RvRestaurantBinding) : RecyclerView.ViewHolder(binding.root)

    private var onItemClickListener: ((RestaurantData) -> Unit)? = null

    fun setOnItemClickListener(position: (RestaurantData) -> Unit) {
        onItemClickListener = position
    }

    private var onItemLongClickListener: ((RestaurantData) -> Unit)? = null

    fun setOnItemLongClickListener(position: (RestaurantData) -> Unit) {
        onItemLongClickListener = position
    }


    private val diffCallback = object : DiffUtil.ItemCallback<RestaurantData>() {

        override fun areContentsTheSame(oldItem: RestaurantData, newItem: RestaurantData): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: RestaurantData, newItem: RestaurantData): Boolean {
            return false
        }

    }


    private val differ = AsyncListDiffer(this, diffCallback)

    var levelList : List<RestaurantData>
        get() = differ.currentList
        set(value) = differ.submitList(value)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = RvRestaurantBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return  LevelViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return levelList.size
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {

        val data = levelList[position]
        holder.itemView.apply {

            with(holder) {

                glide.load(data.image).into(binding.ivRestaurant)
                binding.tvRestaurantname.text = data.name
                binding.tvSecondtext.text = data.text
                binding.ratingbar.rating = data.rating.toFloat()
                binding.tvKm.text = data.km

            }


            setOnClickListener {

                onItemClickListener?.let {
                        click ->
                    click(data)
                }
            }

        }
    }



}