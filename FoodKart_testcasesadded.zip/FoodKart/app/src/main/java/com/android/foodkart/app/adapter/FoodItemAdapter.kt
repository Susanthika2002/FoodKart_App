package com.android.foodkart.app.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.foodkart.app.data.FoodItemData
import com.android.foodkart.app.databinding.RvFooditemBinding

class FoodItemAdapter()  : RecyclerView.Adapter<FoodItemAdapter.LevelViewHolder>()  {

    class LevelViewHolder(val binding : RvFooditemBinding) : RecyclerView.ViewHolder(binding.root)

    private var onItemClickListener: ((FoodItemData) -> Unit)? = null

    fun setOnItemClickListener(position: (FoodItemData) -> Unit) {
        onItemClickListener = position
    }

    private var onItemLongClickListener: ((FoodItemData) -> Unit)? = null

    fun setOnItemLongClickListener(position: (FoodItemData) -> Unit) {
        onItemLongClickListener = position
    }


    private val diffCallback = object : DiffUtil.ItemCallback<FoodItemData>() {

        override fun areContentsTheSame(oldItem: FoodItemData, newItem: FoodItemData): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: FoodItemData, newItem: FoodItemData): Boolean {
            return false
        }

    }


    private val differ = AsyncListDiffer(this, diffCallback)

    var levelList : List<FoodItemData>
        get() = differ.currentList
        set(value) = differ.submitList(value)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = RvFooditemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return  LevelViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return levelList.size
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {

        val data = levelList[position]
        holder.itemView.apply {

            with(holder) {

                binding.ivFood.setImageResource(data.foodItem)

            }


            setOnClickListener {

                onItemClickListener?.let {
                        click ->
                    click(data)
                }
            }

        }
    }



}