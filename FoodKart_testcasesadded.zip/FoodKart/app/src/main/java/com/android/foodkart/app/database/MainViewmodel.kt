package com.android.foodkart.app.database

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.android.foodkart.app.data.FoodData
import com.android.foodkart.app.data.RestaurantData
import com.android.foodkart.app.data.UserData
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainViewmodel : ViewModel() {

    private val firestore = FirebaseFirestore.getInstance()
    private val usersCollection = firestore.collection("users")
    private val restaurantsCollection = firestore.collection("restaurants")
    private val foodsCollection = firestore.collection("foods")

    private var _userCreatedLive = MutableLiveData<UserData>()
    var userCreatedLive : LiveData<UserData> = _userCreatedLive
    private var _errorUserCreatedLive = MutableLiveData<String>()
    var errorUserCreatedLive : LiveData<String> = _errorUserCreatedLive


    fun createUser(userData: UserData) =  viewModelScope.launch(Dispatchers.IO) {

        try {

            val users = usersCollection.whereEqualTo("phoneNumber",userData.phoneNumber).get().await().toObjects(UserData::class.java)

            if(users.isEmpty()){

                usersCollection.document(userData.id).set(userData).addOnSuccessListener {
                    _userCreatedLive.postValue(userData)
                }.addOnFailureListener {
                    _errorUserCreatedLive.postValue(it.message)
                }

            }else{

                _errorUserCreatedLive.postValue("User already exist")

            }

        } catch (e: Exception) {

            _errorUserCreatedLive.postValue(e.message)

        }

    }

    private var _userUpdatedLive = MutableLiveData<UserData>()
    var userUpdatedLive : LiveData<UserData> = _userUpdatedLive
    private var _errorUserUpdatedLive = MutableLiveData<String>()
    var errorUserUpdatedLive : LiveData<String> = _errorUserUpdatedLive

    fun updateUser(userData: UserData) =  viewModelScope.launch(Dispatchers.IO) {

        try {

                usersCollection.document(userData.id).set(userData).addOnSuccessListener {
                    _userUpdatedLive.postValue(userData)
                }.addOnFailureListener {
                    _errorUserUpdatedLive.postValue(it.message)
                }

        } catch (e: Exception) {

            _errorUserUpdatedLive.postValue(e.message)

        }

    }

    fun signInUser(email : String, password : String) =  viewModelScope.launch(Dispatchers.IO) {

        try {

            val users = usersCollection.whereEqualTo("phoneNumber",email).whereEqualTo("password",password).get().await().toObjects(UserData::class.java)

            if(users.isEmpty()){

                _errorUserCreatedLive.postValue("Invalid Credentials")

            }else{

                _userCreatedLive.postValue(users[0])

            }

        } catch (e: Exception) {

            _errorUserCreatedLive.postValue(e.message)

        }

    }

    private var _restaurantsLive = MutableLiveData<List<RestaurantData>>()
    var restaurantsLive : LiveData<List<RestaurantData>> = _restaurantsLive
    private var _errorRestaurantsLive = MutableLiveData<String>()
    var errorRestaurantsLive : LiveData<String> = _errorRestaurantsLive

    fun getRestaurants() =  viewModelScope.launch(Dispatchers.IO) {

        try {

            val levels = restaurantsCollection.get().await().toObjects(RestaurantData::class.java)

            if(levels.isNotEmpty()){

                _restaurantsLive.postValue(levels)

            }else{

                _errorRestaurantsLive.postValue("No Restaurants Found")

            }

        } catch (e: Exception) {

            _errorRestaurantsLive.postValue(e.message)

        }

    }

    private var _foodsLive = MutableLiveData<List<FoodData>>()
    var foodsLive : LiveData<List<FoodData>> = _foodsLive
    private var _errorfoodsLive = MutableLiveData<String>()
    var errorfoodsLive : LiveData<String> = _errorfoodsLive

    fun getFoods(id: String) =  viewModelScope.launch(Dispatchers.IO) {

        try {

            val levels = foodsCollection.whereArrayContains("restaurants",id).get().await().toObjects(FoodData::class.java)

            if(levels.isNotEmpty()){

                _foodsLive.postValue(levels)

            }else{

                _errorfoodsLive.postValue("No foods found")

            }

        } catch (e: Exception) {

            _errorfoodsLive.postValue(e.message)

        }

    }

}
