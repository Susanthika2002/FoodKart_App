package com.android.foodkart.app.data

data class UserData(
    val id: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val phoneNumber: String = "",
    val password: String = "",
    var address: List<AddressData> = listOf(),
    var yourCart : List<CartData> = listOf()
)
data class AddressData(
    val id: String = "",
    val nickName: String = "",
    val phoneNumber: String = "",
    val completeAddress: String = "",
    val landMark: String = "",
    val floorAndRoomNumber: String = ""
)
data class CartData(
    val id: String = "",
    val foodData: FoodData = FoodData(),
    var count: Int = 1
)