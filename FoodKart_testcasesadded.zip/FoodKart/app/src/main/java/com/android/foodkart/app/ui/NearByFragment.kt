package com.android.foodkart.app.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import com.android.foodkart.app.R
import com.android.foodkart.app.adapter.RestaurantAdapter
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentHomeBinding
import com.android.foodkart.app.databinding.FragmentLoginBinding
import com.android.foodkart.app.databinding.FragmentRestaurantsBinding
import com.android.foodkart.app.others.Constants
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref
import com.bumptech.glide.Glide

class NearByFragment : Fragment(R.layout.fragment_restaurants) {

    lateinit var binding: FragmentRestaurantsBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    lateinit var restaurantAdapter: RestaurantAdapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentRestaurantsBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())

        val glide = Glide.with(requireActivity())

        restaurantAdapter = RestaurantAdapter(glide)

        binding.rvRestaurantstoexplore.adapter = restaurantAdapter
        binding.rvRestaurantstoexplore.layoutManager = GridLayoutManager(requireContext(),2)

        viewmodel.getRestaurants()

        viewmodel.restaurantsLive.observe(viewLifecycleOwner, Observer {
            binding.progressbar.visibility = View.GONE
            restaurantAdapter.levelList = it
        })

        viewmodel.errorRestaurantsLive.observe(viewLifecycleOwner, Observer {
            Toast.makeText(requireContext(),it,Toast.LENGTH_SHORT).show()
        })


        restaurantAdapter.setOnItemClickListener {
            Constants.restaurantData = it
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_nearByFragment_to_restaurantFragment)
        }



    }

}