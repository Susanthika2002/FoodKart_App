package com.android.foodkart.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.android.foodkart.app.MainActivity
import com.android.foodkart.app.R
import com.android.foodkart.app.adapter.AddressAdapter
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentAddressesBinding
import com.android.foodkart.app.databinding.FragmentProfileBinding
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref

class ProfileFragment : Fragment(R.layout.fragment_profile) {

    lateinit var binding: FragmentProfileBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentProfileBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        sharedPref = SharedPref(requireContext())


        val userData = sharedPref.getUserData()

        binding.tvCustomername.text = userData.firstName
        binding.tvEmailaddress.text = userData.phoneNumber

        binding.ivBack.setOnClickListener {
            requireActivity().onBackPressed()
        }


        binding.tvYourorders.setOnClickListener {
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_profileFragment_to_cartFragment)
        }

        binding.tvAddressbook.setOnClickListener {
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_profileFragment_to_addressesFragment)
        }

        binding.tvLogout.setOnClickListener {
            sharedPref.setUserLoginStatus(false)
            startActivity(Intent(requireActivity(),MainActivity::class.java))
            requireActivity().finish()
        }


    }



}