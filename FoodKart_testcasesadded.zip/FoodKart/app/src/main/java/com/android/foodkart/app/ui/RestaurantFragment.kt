package com.android.foodkart.app.ui

import android.app.NotificationChannel
import android.app.NotificationManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat.IMPORTANCE_HIGH
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.foodkart.app.R
import com.android.foodkart.app.adapter.FoodAdapter
import com.android.foodkart.app.adapter.RestaurantAdapter
import com.android.foodkart.app.data.CartData
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentHomeBinding
import com.android.foodkart.app.databinding.FragmentLoginBinding
import com.android.foodkart.app.databinding.FragmentRestauranthomeBinding
import com.android.foodkart.app.databinding.FragmentRestaurantsBinding
import com.android.foodkart.app.others.Constants
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref
import com.bumptech.glide.Glide
import kotlin.random.Random
import android.content.Context

private const val CHANNEL_ID = "foodkart_channel"

class RestaurantFragment : Fragment(R.layout.fragment_restauranthome) {

    lateinit var binding: FragmentRestauranthomeBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    lateinit var restaurantAdapter: FoodAdapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentRestauranthomeBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())

        val userData = sharedPref.getUserData()

        val glide = Glide.with(requireActivity())


        val data = Constants.restaurantData

        glide.load(data.image).into(binding.ivRestaurant)
        binding.tvRestaurantname.text = data.name
        binding.tvSecondtext.text = data.text
        binding.tvKm.text = data.km
        binding.ratingbar.rating = data.rating.toFloat()


        binding.ivBack.setOnClickListener {
            requireActivity().onBackPressed()
        }


        restaurantAdapter = FoodAdapter(glide)

        binding.rvRestaurantstoexplore.adapter = restaurantAdapter
        binding.rvRestaurantstoexplore.layoutManager = LinearLayoutManager(requireContext())

        viewmodel.getFoods(data.id)

        viewmodel.foodsLive.observe(viewLifecycleOwner, Observer {
            binding.progressbar.visibility = View.GONE
            restaurantAdapter.levelList = it
        })

        viewmodel.errorfoodsLive.observe(viewLifecycleOwner, Observer {
            Toast.makeText(requireContext(),it,Toast.LENGTH_SHORT).show()
        })


        restaurantAdapter.setOnItemClickListener {
            myDialog.showProgressDialog("Adding",this)
            val oldCartItems = userData.yourCart.toMutableList()
            val id = (0..10000000).random().toString()
            val newCart = CartData(id,it,1)
            oldCartItems.add(newCart)

            viewmodel.updateUser(userData.apply {
                this.yourCart = oldCartItems
            })

        }

        viewmodel.userUpdatedLive.observe(viewLifecycleOwner, Observer {
            myDialog.dismissProgressDialog()
            sharedPref.setUserData(it)
            sendNotification()
            Toast.makeText(requireContext(),"Item added in my cart",Toast.LENGTH_SHORT).show()
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_content_main)
                .navigate(R.id.action_restaurantFragment_to_cartFragment)
        })

        viewmodel.errorUserUpdatedLive.observe(viewLifecycleOwner, Observer {
            myDialog.dismissProgressDialog()
            Toast.makeText(requireContext(),it,Toast.LENGTH_SHORT).show()
        })


    }

    private fun sendNotification(){

        val notificationManager = requireActivity().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationID = Random.nextInt()

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel(notificationManager)
        }

        val notification = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setContentTitle("New item added in cart")
            .setContentText("Just now")
            .setSmallIcon(R.drawable.ic_stat_notification)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_SOUND)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        notificationManager.notify(notificationID, notification)

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel(notificationManager: NotificationManager) {
        val channelName = "Foodkart"
        val channel = NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Foodkart channel description"
            enableLights(true)
            lightColor = Color.GREEN
        }
        notificationManager.createNotificationChannel(channel)
    }

}