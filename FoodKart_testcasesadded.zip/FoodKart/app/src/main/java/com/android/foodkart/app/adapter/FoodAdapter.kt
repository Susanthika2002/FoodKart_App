package com.android.foodkart.app.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.foodkart.app.R
import com.android.foodkart.app.data.FoodData
import com.android.foodkart.app.data.ReviewData
import com.android.foodkart.app.databinding.RvFoodBinding
import com.android.foodkart.app.databinding.RvFooditemBinding
import com.bumptech.glide.RequestManager

class FoodAdapter(val glide: RequestManager)  : RecyclerView.Adapter<FoodAdapter.LevelViewHolder>()  {

    class LevelViewHolder(val binding : RvFoodBinding) : RecyclerView.ViewHolder(binding.root)

    private var onItemClickListener: ((FoodData) -> Unit)? = null

    fun setOnItemClickListener(position: (FoodData) -> Unit) {
        onItemClickListener = position
    }

    private var onItemLongClickListener: ((FoodData) -> Unit)? = null

    fun setOnItemLongClickListener(position: (FoodData) -> Unit) {
        onItemLongClickListener = position
    }


    private val diffCallback = object : DiffUtil.ItemCallback<FoodData>() {

        override fun areContentsTheSame(oldItem: FoodData, newItem: FoodData): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: FoodData, newItem: FoodData): Boolean {
            return false
        }

    }


    private val differ = AsyncListDiffer(this, diffCallback)

    var levelList : List<FoodData>
        get() = differ.currentList
        set(value) = differ.submitList(value)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = RvFoodBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return  LevelViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return levelList.size
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {

        val data = levelList[position]
        holder.itemView.apply {

            with(holder) {

             glide.load(data.image).into(binding.ivFood)
             binding.tvFoodname.text = data.name
             binding.tvPrice.text = data.text
             binding.ratingbar.rating = data.rating.toFloat()

                binding.btAdd.setOnClickListener {
                    onItemClickListener?.let {
                            click ->
                        click(data)
                    }
                }

             binding.tvFooddetails.setOnClickListener {
                 binding.rvReviews.visibility = View.GONE
                 binding.cdFooddetails.visibility = View.VISIBLE
                 binding.tvFooddetails.setTextColor(ContextCompat.getColor(context, R.color.purple_500))
                 binding.tvReview.setTextColor(ContextCompat.getColor(context, R.color.black))
             }

            binding.tvReview.setOnClickListener {
                binding.rvReviews.visibility = View.VISIBLE
                binding.cdFooddetails.visibility = View.GONE
                binding.tvFooddetails.setTextColor(ContextCompat.getColor(context, R.color.black))
                binding.tvReview.setTextColor(ContextCompat.getColor(context, R.color.purple_500))
            }

                val reviewAdapter = ReviewsAdapter()
                binding.rvReviews.adapter = reviewAdapter
                binding.rvReviews.layoutManager = LinearLayoutManager(context)

                reviewAdapter.levelList = data.reviews

                binding.tvFoodetailsValue.text = data.foodDetails

            }


            setOnClickListener {

            }

        }
    }



}