package com.android.foodkart.app.others

import android.content.Context
import com.android.foodkart.app.data.UserData
import com.google.gson.Gson


class SharedPref(context: Context) {

    val sharedpref = context.getSharedPreferences("foodkart_pref", Context.MODE_PRIVATE)
    val editor = sharedpref.edit()

    val USERDATA = "userdata"
    val USERLOGIN = "userlogin"
    val UPDATEWALLETPENDING = "UpdateWalletPending"
    val UPDATEWALLETMONEY = "UpdateWalletMoney"
    val ADDRESS = "Address"
    val CITY = "City"

    fun setUserData(userData: UserData){
        val gson =  Gson()
        val json = gson.toJson(userData)
        editor.putString(USERDATA, json)
        editor.putBoolean(USERLOGIN,true)
        editor.commit()
    }

    fun setUserLoginStatus(status : Boolean) {
        editor.apply {
            putBoolean(USERLOGIN,status)
            apply()
        }
    }

    fun setAddress(address  : String) {
        editor.apply {
            putString(ADDRESS,address)
            apply()
        }
    }

    fun setCity(city  : String) {
        editor.apply {
            putString(CITY,city)
            apply()
        }
    }

    fun getAddress() : String{
        return sharedpref.getString(ADDRESS,"No location") ?: "No location"
    }

    fun getCity() : String{
        return sharedpref.getString(CITY,"No location") ?: "No location"
    }


    fun updateWalletStatus(status : Boolean) {
        editor.apply {
            putBoolean(UPDATEWALLETPENDING,status)
            apply()
        }
    }

    fun updateWalletMoney(amount : Long) {
        editor.apply {
            putLong(UPDATEWALLETMONEY,amount)
            apply()
        }
    }

    fun getUserLoginStatus() : Boolean{
        return sharedpref.getBoolean(USERLOGIN,false)
    }

    fun getUpdateWalletMoney() : Long{
        return sharedpref.getLong(UPDATEWALLETMONEY,0L)
    }

    fun getUpdateWalletStatus() : Boolean{
        return sharedpref.getBoolean(UPDATEWALLETPENDING,false)
    }

    fun getUserData() : UserData {
        val gson = Gson()
        val json = sharedpref.getString(USERDATA, "null")
        return gson.fromJson(json, UserData::class.java)
    }





}