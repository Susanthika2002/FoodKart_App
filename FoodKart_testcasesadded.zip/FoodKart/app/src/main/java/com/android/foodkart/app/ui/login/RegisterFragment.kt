package com.android.foodkart.app.ui.login

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.android.foodkart.app.MainActivity
import com.android.foodkart.app.R
import com.android.foodkart.app.data.UserData
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentLoginBinding
import com.android.foodkart.app.databinding.FragmentRegisterBinding
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref

class RegisterFragment : Fragment(R.layout.fragment_register) {

    lateinit var binding: FragmentRegisterBinding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentRegisterBinding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())

        binding.tvSignin.setOnClickListener {
            Navigation.findNavController(requireActivity(),R.id.nav_host_fragment_content_main).navigate(R.id.action_registerFragment_to_loginFragment)
        }

        binding.cdSignup.setOnClickListener {
            signUp()
        }


        setCallbacks()



    }

    private fun signUp() {

        val phone = binding.edPhonenumber.text.toString()
        val password = binding.edPassword.text.toString()
        val confirmPassword = binding.edConfirmpassword.text.toString()
        val firstName = binding.edFirstname.text.toString()
        val lastName = binding.edSecondname.text.toString()


        if (!RegistrationUtil.validRegistrationInputs(phone,password,confirmPassword,firstName,lastName)){
            Toast.makeText(requireContext(), "Please enter all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (!RegistrationUtil.validPasswordDigits(password)){
            Toast.makeText(requireContext(), "Password contains minimum 4 characters", Toast.LENGTH_SHORT).show()
            return
        }

        if (!RegistrationUtil.validConfirmPassword(password,confirmPassword)){
            Toast.makeText(requireContext(), "Password mismatching", Toast.LENGTH_SHORT).show()
            return
        }

        if (!RegistrationUtil.validPhoneNumber(phone)){
            Toast.makeText(requireContext(), "Invalid phone number", Toast.LENGTH_SHORT).show()
            return
        }

        viewmodel.createUser(UserData(phone,firstName,lastName,phone,password))

        myDialog.showProgressDialog("Please wait",this)

    }


    private fun setCallbacks() {


        viewmodel.userCreatedLive.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            myDialog.dismissProgressDialog()
            sharedPref.setUserData(it)
            (activity as MainActivity).isLocationPermissionGranted()
            Navigation.findNavController(requireActivity(),R.id.nav_host_fragment_content_main).navigate(R.id.action_registerFragment_to_homeFragment2)

        })

        viewmodel.errorUserCreatedLive.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            myDialog.dismissProgressDialog()
            myDialog.showErrorAlertDialog(it)
        })

    }

}