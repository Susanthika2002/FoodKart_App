package com.android.foodkart.app.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.foodkart.app.data.AddressData
import com.android.foodkart.app.databinding.RvAddressBinding
import com.android.foodkart.app.databinding.RvFoodBinding
import com.android.foodkart.app.databinding.RvFooditemBinding
import com.bumptech.glide.RequestManager

class AddressAdapter()  : RecyclerView.Adapter<AddressAdapter.LevelViewHolder>()  {

    class LevelViewHolder(val binding : RvAddressBinding) : RecyclerView.ViewHolder(binding.root)

    private var onItemClickListener: ((AddressData) -> Unit)? = null

    fun setOnItemClickListener(position: (AddressData) -> Unit) {
        onItemClickListener = position
    }

    private var onItemLongClickListener: ((AddressData) -> Unit)? = null

    fun setOnItemLongClickListener(position: (AddressData) -> Unit) {
        onItemLongClickListener = position
    }


    private val diffCallback = object : DiffUtil.ItemCallback<AddressData>() {

        override fun areContentsTheSame(oldItem: AddressData, newItem: AddressData): Boolean {
            return oldItem == newItem
        }

        override fun areItemsTheSame(oldItem: AddressData, newItem: AddressData): Boolean {
            return false
        }

    }


    private val differ = AsyncListDiffer(this, diffCallback)

    var levelList : List<AddressData>
        get() = differ.currentList
        set(value) = differ.submitList(value)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = RvAddressBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return  LevelViewHolder(binding)
    }


    override fun getItemCount(): Int {
        return levelList.size
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {

        val data = levelList[position]
        holder.itemView.apply {

            with(holder) {

                binding.tvLocation.text = data.nickName
                binding.tvLocationname.text = data.completeAddress

            }


            setOnClickListener {

            }

        }
    }



}