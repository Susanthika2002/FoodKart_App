package com.android.foodkart.app.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.android.foodkart.app.R

class SupportFragment : Fragment(R.layout.fragment_support) {


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


}