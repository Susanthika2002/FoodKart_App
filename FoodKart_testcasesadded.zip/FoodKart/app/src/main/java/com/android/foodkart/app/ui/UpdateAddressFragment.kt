package com.android.foodkart.app.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.foodkart.app.R
import com.android.foodkart.app.adapter.AddressAdapter
import com.android.foodkart.app.adapter.FoodItemAdapter
import com.android.foodkart.app.data.AddressData
import com.android.foodkart.app.database.MainViewmodel
import com.android.foodkart.app.databinding.FragmentAddaddress1Binding
import com.android.foodkart.app.databinding.FragmentAddressesBinding
import com.android.foodkart.app.databinding.FragmentHomeBinding
import com.android.foodkart.app.others.Constants
import com.android.foodkart.app.others.MyDialog
import com.android.foodkart.app.others.SharedPref

class UpdateAddressFragment : Fragment(R.layout.fragment_addaddress1) {


    lateinit var binding: FragmentAddaddress1Binding
    lateinit var viewmodel : MainViewmodel
    lateinit var myDialog: MyDialog
    lateinit var sharedPref: SharedPref
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentAddaddress1Binding.bind(view)
        setUI()

    }

    private fun setUI() {

        viewmodel =
            ViewModelProvider(this).get(MainViewmodel::class.java)
        myDialog = MyDialog(requireContext())
        sharedPref = SharedPref(requireContext())

        val userData = sharedPref.getUserData()

        val data = Constants.curAddressData

        binding.edNickname.setText(data.nickName)
        binding.edCompleteaddress.setText(data.completeAddress)
        binding.edLandmark.setText(data.landMark)
        binding.edFloorphonenumber.setText(data.floorAndRoomNumber)
        binding.edReceiverphonenumber.setText(data.phoneNumber)

        binding.cdAddaddress.setOnClickListener {

            val nickName = binding.edNickname.text.toString()
            val receiverPhoneNumber = binding.edReceiverphonenumber.text.toString()
            val completeAddress = binding.edCompleteaddress.text.toString()
            val landmark = binding.edLandmark.text.toString()
            val floorRoomNumber = binding.edFloorphonenumber.text.toString()

            if (nickName.isEmpty()){
                Toast.makeText(requireContext(),"Please enter name",Toast.LENGTH_SHORT).show()
            }
            if (completeAddress.isEmpty()){
                Toast.makeText(requireContext(),"Please enter address",Toast.LENGTH_SHORT).show()
            }

            val addressData = AddressData(nickName,nickName,receiverPhoneNumber,completeAddress,landmark,floorRoomNumber)

            val addresses = userData.address.toMutableList()
            addresses.filter { it.id == data.id }
            addresses.removeAll(addresses)
            addresses.add(addressData)

            sharedPref.setUserData(userData.apply {
                this.address = addresses
            })

            viewmodel.updateUser(sharedPref.getUserData())

            myDialog.showProgressDialog("Adding address",this)

        }

        viewmodel.userUpdatedLive.observe(viewLifecycleOwner, Observer {
            myDialog.dismissProgressDialog()
            sharedPref.setUserData(it)
            Toast.makeText(requireContext(),"Address added",Toast.LENGTH_SHORT).show()
            requireActivity().onBackPressed()
        })

        viewmodel.errorUserUpdatedLive.observe(viewLifecycleOwner, Observer {
            myDialog.dismissProgressDialog()
            Toast.makeText(requireContext(),it,Toast.LENGTH_SHORT).show()
        })

        binding.ivBack.setOnClickListener {
            requireActivity().onBackPressed()
        }

    }


}