package com.android.foodkart.app.ui.login


import com.google.common.truth.Truth.assertThat
import org.junit.Test

class RegistrationUtilTest {


    @Test
    fun `empty input fields returns false`(){
        val result = RegistrationUtil.validRegistrationInputs(
            "",
            "123",
            "123",
            "Arun",
            "Mohan"
        )
        assertThat(result).isFalse()
    }

    @Test
    fun `correctly repeated password returns true`() {
        val result = RegistrationUtil.validConfirmPassword(
            "1234",
            "1234"
        )
        assertThat(result).isTrue()
    }

    @Test
    fun `incorrect confirm password returns false`() {
        val result = RegistrationUtil.validConfirmPassword(
            "1234",
            "12344"
        )
        assertThat(result).isFalse()
    }

    @Test
    fun `less than 4 digit password returns false`() {
        val result = RegistrationUtil.validPasswordDigits(
            "123"
        )
        assertThat(result).isFalse()
    }

    @Test
    fun `less than 4 digit password returns true`() {
        val result = RegistrationUtil.validPasswordDigits(
            "1234"
        )
        assertThat(result).isTrue()
    }


}